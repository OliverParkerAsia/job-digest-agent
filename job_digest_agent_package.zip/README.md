# 🎯 HK Job Digest Agent

This GitHub Action queries your fine-tuned OpenPipe model and sends a daily job digest to your email inbox.

## 🔧 Setup

1. Add these **repository secrets**:
   - `OPENPIPE_API_KEY`
   - `MODEL_ID` (e.g., `hk-job-agent-v1`)
   - `FROM_EMAIL` (your Gmail address)
   - `TO_EMAIL` (recipient email)
   - `GMAIL_APP_PASSWORD` (from your Google account's App Passwords page)

2. The job will run **daily at 9am UTC / 5pm HKT** and send you a curated job list.

You can also trigger it manually from the Actions tab.
