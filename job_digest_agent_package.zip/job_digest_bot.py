import requests
import smtplib
from email.message import EmailMessage
import os

# === SECRETS FROM ENV ===
OPENPIPE_API_KEY = os.environ["OPENPIPE_API_KEY"]
MODEL_ID = os.environ["MODEL_ID"]
FROM_EMAIL = os.environ["FROM_EMAIL"]
TO_EMAIL = os.environ["TO_EMAIL"]
GMAIL_APP_PASSWORD = os.environ["GMAIL_APP_PASSWORD"]

# === QUERY ===
query = {
    "messages": [
        {
            "role": "user",
            "content": "What are today's new media education jobs in or open to Hong Kong applicants?"
        }
    ]
}

response = requests.post(
    f"https://api.openpipe.ai/inference/{MODEL_ID}",
    headers={"Authorization": f"Bearer {OPENPIPE_API_KEY}", "Content-Type": "application/json"},
    json=query
)

output = response.json().get("output", "(No results from model.)")

# === EMAIL ===
msg = EmailMessage()
msg["Subject"] = "🎯 Daily Job Digest — Hong Kong Media Roles"
msg["From"] = FROM_EMAIL
msg["To"] = TO_EMAIL
msg.set_content(output)

with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
    smtp.login(FROM_EMAIL, GMAIL_APP_PASSWORD)
    smtp.send_message(msg)

print("✅ Job digest sent to", TO_EMAIL)
